# Website for *Le Camping des Speakers*

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/RdvSpeakers/camping-des-speakers-website.git)


## An [Eleventy](https://11ty.dev/) site

*[Le Camping des Speakers](https://github.com/RdvSpeakers/camping-des-speakers-website/)* is statically generated from this source code  with the [Eleventy](https://11ty.dev/) static site generator using [JavaScript templates (*.11ty.js)](https://11ty.dev/languages/javascript/).

It's based on [eleventy-dot-js-blog](https://gitlab.com/reubenlillie/eleventy-dot-js-blog) started made by [Reuben L. Lillie](https://twitter.com/reubenlillie).


## Getting started

Simply open the [project on GitPod]((https://gitpod.io/#https://github.com/RdvSpeakers/camping-des-speakers-website.git)!

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/RdvSpeakers/camping-des-speakers-website.git)

Or if you want/need to run a local copy of this site on your computer:

Install [Node.js](https://nodejs.org/) on your machine (see [11ty documentation for version requirements](https://www.11ty.dev/docs/getting-started/)).

Then enter the following commands into your terminal:

### 1. Clone this repository and all its dependencies

```cli
git clone git@gitlab.com:reubenlillie/eleventy-dot-js-blog.git my-blog-directory-name
```

### 2. Go to the working directory

```cli
cd my-blog-directory-name
```
Specifically take a look at the file named [`.eleventy.js`](https://gitlab.com/reubenlillie/eleventy-dot-js-blog/-/blob/master/.eleventy.js) to see if you want to [configure any Eleventy options differently](https://www.11ty.dev/docs/config/).

### 3. Install the project dependencies with [NPM](https://www.npmjs.com/)

```cli
npm install
```

### 4. Edit the `.js` files in the [`_data`](https://gitlab.com/reubenlillie/eleventy-dot-js-blog/-/blob/master/_data/site.js) directory with your site information

### 5. Run Eleventy

```cli
npx eleventy
```

Or build and host locally for local development

```cli
npx eleventy --serve
```

Or build automatically when a template changes

```cli
npx eleventy --watch
```

Or in debug mode

```cli
DEBUG=* npx eleventy
```
&copy; 2021 by [Horacio Gonzalez](https://twitter.com/LostInBrittany)
