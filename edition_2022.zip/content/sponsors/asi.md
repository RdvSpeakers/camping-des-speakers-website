---
key: asi
title: ASI
category: 2048
logoURL: logos/2048-ASI-format-rond-rouge.png
url: https://www.asi.fr/
socials: []
---