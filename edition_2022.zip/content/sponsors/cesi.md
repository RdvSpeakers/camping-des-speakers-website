---
key: cesi
title: CESI
category: 2048
logoURL: logos/2048-cesi.png
url: https://www.cesi.fr/
socials: []
---