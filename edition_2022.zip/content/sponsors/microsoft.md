---
key: microsoft
title: Microsoft
category: 2048
logoURL: logos/2048-microsoft.png
url: https://www.microsoft.com/fr-fr
socials: []
---