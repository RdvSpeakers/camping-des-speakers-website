---
key: philippe_charriere
name: Philippe Charrière
company: GitLab
city: Lyon, France
photoURL: team/philippe_charriere.jpg
socials:
  - icon: twitter
    link: 'https://www.twitter.com/k33g_org'
  - icon: linkedin
    link: 'https://www.linkedin.com/in/phcharriere'
  - icon: github
    link: 'https://github.com/k33g'
---

