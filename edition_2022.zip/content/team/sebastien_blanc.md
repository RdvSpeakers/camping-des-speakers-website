---
key: sebastien_blanc
name: Sébastien Blanc
company: RedHat
photoURL: team/sebastien_blanc.jpg
socials:
  - icon: twitter
    link: 'https://www.twitter.com/sebi2706'
  - icon: linkedin
    link: 'https://www.linkedin.com/in/sébastien-blanc-08a73b1'
  - icon: github
    link: 'https://github.com/sebastienblanc'
---

