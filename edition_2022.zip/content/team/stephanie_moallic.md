---
key: stephanie_moallic
name: Stéphanie Moallic
company: OVHcloud
city: Brest, France
photoURL: team/stephanie_moallic.jpg
socials:
  - icon: twitter
    link: https://twitter.com/steffy_29
    name: steffy_29
  - icon: github
    link: https://github.com/Steffy29
    name: Steffy29
---
Développeuse logicielle depuis 20 ans, j'ai commencé par faire des interfaces en langage C pour m'orienter ensuite vers les technologies Web en passant par Java et le développement mobile. En parallèle de mon activité de développeuse, j'apprécie de partager mes connaissances en donnant des cours de programmation ou en organisant des ateliers pour les enfants tels que le Devoxx4Kids by Code Ar Vugale. Je participe aussi à promouvoir les femmes dans les métiers dans l'informatique en participant aux Duchess France et à d'autres conférences autour de ce sujet. Mon prochain défi: concevoir et construire mon propre robot qui marche à base de micro:bit, carte électronique qui me permet d'imaginer pleins d'idées et de projets fous...