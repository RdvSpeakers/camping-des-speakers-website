---
key: francois_teychene
name: François Teychene
company: " " 
city: Montpellier, France
photoURL: ./team/francois_teychene.jpg
socials:
  - icon: twitter
    link: 'https://www.twitter.com/fteychene'
  - icon: linkedin
    link: 'https://www.linkedin.com/in/fteychene'
  - icon: github
    link: 'https://github.com/fteychene'
---

