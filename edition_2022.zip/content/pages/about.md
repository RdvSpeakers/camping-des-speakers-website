---
title: Le Camping des Speakers
navTitle: À propos
tags: nav
weight: 2
permalink: about
---

*Le Camping des Speakers* est une déclinaison "physique" des [*Rendez-vous des Speakers*](https://rdv-speakers.fr/).

L'idée est de se rencontrer tous, organisateurs, speakers et participants, dans un environnement différent des conférences habituelles.

Le camping a tous l'équipement nécessaire pour des talks et apporte une coloration plus détendue par son infrastructure ludique.

Au delà des talks classiques (2 salles avec projection de slides) nous motivons les speakers pour proposer des talks moins classiques en utilisant la piscine, le terrain de pétanque, la zone barbecue, un karaoke, une sortie en poney ou en kayak dans le Golfe...
