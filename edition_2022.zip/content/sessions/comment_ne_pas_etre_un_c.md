---
key: comment_ne_pas_etre_un_c
title: "comment (ne pas) être un c*nnard en 5 leçons 🤗"
speakers:
  - noel_mace
  - valeriane_venance
type: bivouac
day: 0
time: 21h00
duration: 45 minutes
room: slideless
---

On est tous d'accord : on peut jamais être d'accord !

Là où certains tentent de faciliter la conversation, d'autres se font une joie de la bloquer.

Comment faire pour communiquer malgré tout alors que ça semble de plus en plus impossible ?

Dans la vie perso comme au boulot, voici 5 outils concrets pour (ne pas) être un connard.