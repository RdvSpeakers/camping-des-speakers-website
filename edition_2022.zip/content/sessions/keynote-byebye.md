---
key: keynote-byebye
title: "Keynote d'Au Revoir"
speakers:
  - horacio_gonzalez
type: quechua
day: 0
time: 16h00
duration: 20 minutes
room: petite_salle
---
