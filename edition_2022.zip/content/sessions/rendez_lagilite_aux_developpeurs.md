---
key: rendez_lagilite_aux_developpeurs
title: "Rendez l'agilité aux développeur(se)s&nbsp;!"
speakers:
  - fanny_klauk 
type: autour_du_feu
day: 0
time: 14h55
duration: 15 minutes
room: autour_du_feu
---

Nous parlons rendement au lieu de parler d’efficacité. On parle de ROI au lieu d’amélioration continue. On privilégie la surveillance à la place du soutien et comptes-rendus au lieu de protection de l’équipe : mais rendez-nous notre agilité ! Rappelons-nous que l’agilité a été pensée par et pour les développeurs, désireux de créer des services utiles et utilisés, de manière gratifiante, dans des contextes variants et variables.

Ré-accaparons-nous notre pouvoir d'équipes Super Agiles ! 🦸‍♂️ 🦸‍♀️

A travers des scénettes, au travers de notre "livre dont tu es le héros" 📖 , nous verrons comment chaque acteur, qu'il soit Manager, Pilote transverse, Coach agile ou bien Client, peut contribuer à nous redonner les vraies clés 🔑 de votre agilité.
