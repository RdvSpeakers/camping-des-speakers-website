---
key: la_fabrication_du_cognac_cest_pas_sorcier
title: "La fabrication du Cognac, c'est pas sorcier (mais c'est magique) 🥃"
speakers:
  - virginie_casavecchia
type: autour_du_feu
day: 0
time: 21h00
duration: 15 minutes
room: autour_du_feu
---

Célèbre et exporté partout dans le monde, le Cognac ne peut être produit que dans une petite zone des charentes, autour de la ville du même nom.
Suivez-moi à la découverte de ce savoir-faire vieux de plus de 300 ans (sans camion, mais avec des maquettes fait-maison).

---

L'abus d'alcool est dangereux pour la santé, à consommer avec modération.