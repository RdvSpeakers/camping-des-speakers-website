---
key: bourse-aux-talks
title: "Bourse aux talks"
speakers: 
  - ''
type: quechua
day: 1
time: 09h00
duration: 20 minutes
room: grande_salle
---
