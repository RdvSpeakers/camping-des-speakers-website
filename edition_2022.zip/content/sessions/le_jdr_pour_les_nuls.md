---
key: le_jdr_pour_les_nuls
title: "Le JDR pour les nuls"
speakers:
  - thibault_goudouneix
type: autour_du_feu
day: 0
time: 14h30
duration: 15 minutes
room: autour_du_feu
---

Gary Gygax, créateur du premier Jeu de Rôles, disait en interview téléphonique : "L'essence d'un jeu de rôle est que c'est une expérience de groupe, une expérience de coopération. Il n'y a ni victoire ni défaite, mais la valeur est dans l'expérience consistant à vous imaginer dans la peau d'un personnage dans le genre fictionnel que vous pratiquez". Dans ce court talk, je ferai une introduction au JDR et son intérêt en milieu professionnel.