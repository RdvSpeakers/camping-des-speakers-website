---
key: le_pire_talk_de_ma_vie
title: "Le pire talk de ma vie"
speakers:
  - jordane_grenat 
type: autour_du_feu
day: 0
time: 13h55
duration: 15 minutes
room: autour_du_feu
---

Venez et écoutez, chers auditeurs, le récit versifié de mon malheur ! Moi qui pensais présenter mon sujet avec maîtrise, j'ai surtout réalisé ma méprise !

Je vais vous conter cette mésaventure, celle d'une conférence devenue déconfiture, où les éléments se liguaient contre moi, où mon bonheur est devenu effroi !

Nous tirerons les leçons de mon infortune, avec quelques recommandations opportunes. Des trucs, astuces et bonnes pratiques, pour ne pas sombrer dans la panique.

Et si par bonheur vous souhaitez vous lancer, vous trouverez autour de ce feu des alliés !
