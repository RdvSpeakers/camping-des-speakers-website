---
key: et_si_on_faisait_le_tour_de_cors
title: "Et si on faisait le tour de CORS&nbsp;?&nbsp;⛵"
speakers:
  - cedric_gatay
type: tente_cannadienne
day: 0
time: 11h15
duration: 45 minutes
room: petite_salle
---

Embarquez avec moi pour profiter du panorama magnifique proposé par les lieux avant de découvrir ses trésors cachés !

Le web devient de plus en plus sécuritaire, il est possible de protéger plus efficacement nos APIs en utilisant les bons headers.

Cependant, savez-vous réellement ce qui se cache derrière ce mal aimé CORS ?

Dans ce sujet nous allons aborder l'origine de la technique et expliquer comment tout ceci fonctionne pour que vous puissiez devenir le chief-CORS-officer de l'équipe !