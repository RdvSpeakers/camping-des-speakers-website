---
key: maximiser_votre_turn-over
title: "Maximiser votre turn-over : pourquoi et comment"
speakers:
  - lucien_bill
type: autour_du_feau
day: 1
time: 09h40
duration: 15 minutes
room: autour_du_feu
---

Chez beaucoup d’acteurs du digital, l’accent est mis sur le bien-être au travail afin de fidéliser les salariés. Dans ce talk satirique, je réponds à 2 questions : pourquoi, et comment faire exactement l’inverse !