---
key: lead_Dev_3_ans_dxp
title: "Lead Dev, 3 ans d'xp, et alors ?  "
speakers:
  - lise_quesnel
type: quechua
day: 0
time: 17h10
duration: 20 minutes
room: grande_salle
---

Un lead dev, vous l'imaginez comment ? Barbu, plus de 10 ans d'expérience, seul à pouvoir valider du code ? Spoiler alert : je ne ressemble pas à ça !

Lorsque ce rôle m'a été "attribué", je n'avais que 3 années d'expérience à l'époque. Qu'ai-je bien pu faire pour en arriver là ? Quelles difficultés j'ai pu rencontrer ?

D'ailleurs, tech lead, lead dev, quelle différence fais-je ? 🤔Comment je vois mon rôle et comment j'essaie de jouer ce rôle au mieux ? Quelles sont les responsabilités d'un tel statut ?

Au quotidien, comment cela se passe-t-il ? Mon terminal prend-il la poussière ? 😱

Durant ce talk, nous analyserons ensemble les différents aspects d'un tel rôle et comment cela se traduit au quotidien pour l'équipe. Nous verrons que tous ces aspects ne sont pas obligatoirement portés par la même personne, et que cela peut être bénéfique pour l'ensemble de l'équipe de développement. 💪