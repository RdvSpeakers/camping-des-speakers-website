---
key: kubernetes_le_coeur_de_la_meule
title: "Kubernetes : le coeur de la meule … comme vous ne l’avez jamais vu"
speakers:
  - aurelie_vache 
type: bivouac
day: 0
time: 13h30
duration: 45 minutes
room: slideless
---

Kubernetes, on en entend parler du soir au matin, tous les jours des articles sur la techno paraissent, tout le monde en fait, veux en faire, que ce soit en dev, pour un PoC ou en production... Mais, "c'est compliqué", "c'est pas pour moi", "pas envie de lire tous les changelogs", "je m'embrouille toujours dans les composants de kube", "j'suis pas ops", "je comprend pas"... 

Et si je vous dit, que l'on peut voir ensemble une overview de Kubernetes avec des tips et astuces, de manière résumée, imagée et simplifiée ? 

On va essayer de relever le double challenge d’expliquer Kubernetes sans slides, sans terminal, mais avec des accessoires, de la créativité et de l’imagination ! Vous êtes partant ?
