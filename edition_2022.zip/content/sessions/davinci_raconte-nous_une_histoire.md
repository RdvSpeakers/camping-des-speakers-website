---
key: davinci_raconte-nous_une_histoire
title: "Davinci, raconte-nous une histoire!"
speakers:
  - tiffany_souterre
type: autour_du_feu
day: 0
time: 21h25
duration: 15 minutes
room: autour_du_feu
---

Avez-vous déjà écouté une histoire d'horreur improvisée par une Intelligence artificielle ? Venez nous rejoindre autour du feu et installez-vous confortablement. Davinci, une IA créée par OpenAI, viendra accompagnée de Tiffany qui lui prêtera sa voix pour raconter une histoire d'horreur sur le thème que vous choisirez.

Davinci étant plus performant en anglais, l'histoire sera contée en anglais.