---
key: indiana_jones_et_les_aventuriers_de_la_conf_perdue
title: "Indiana Jones et les aventuriers de la conf perdue"
speakers:
  - benjamin_dauvissat 
type: autour_du_feu
day: 0
time: 16h25
duration: 15 minutes
room: autour_du_feu
---

Comment survivre chez un client qui ne sait pas ce qui est installé sur ses serveurs, ne possède pas les sources des applis à maintenir, ou alors, si, mais il ne sait plus où elles sont.

Ma plongée dans un univers terrifiant et anxiogène , les coups de sangs, les coups de cœur, les travaux pour en sortir.