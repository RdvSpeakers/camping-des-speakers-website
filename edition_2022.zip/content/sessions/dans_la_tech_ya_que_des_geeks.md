---
key: dans_la_tech_ya_que_des_geeks
title: "Dans la tech, y a que des geeks !"
speakers:
  - benjamin_dauvissat 
type: quechua
day: 0
time: 17h10
duration: 20 minutes
room: petite_salle
---

Catégorie "Atypique" Dans les métiers de la tech, il semble que la proportion de neuro-atypiques (HPI, Asperger, etc.) soit au dessus de la moyenne nationale. Pourquoi ? Qu'est-ce que cela implique pour ces profils ? Retour sur un vécu personnel agrémenté de quelques recherches plus larges sur le sujet.