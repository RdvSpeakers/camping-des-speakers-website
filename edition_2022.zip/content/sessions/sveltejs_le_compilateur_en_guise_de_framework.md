---
key: sveltejs_le_compilateur_en_guise_de_framework
title: "Svelte.js : Le compilateur en guise de Framework"
speakers:
  - thibault_goudouneix
type: tente_canadienne
day: 1
time: 11h15
duration: 45 minutes
room: grande_salle
---

Depuis la sortie de sa version 3 en avril 2019, le "framework" Svelte fait de plus en plus parler de lui. De par sa légèreté et son approche à contre-pied des incontournables comme React ou Angular, l'étoile montante développée par Rich Harris, vous promet simplicité et rapidité, pour une meilleure expérience utilisateur et développeur. Et vous, vous laisserez-vous tenter par Svelte.js ?