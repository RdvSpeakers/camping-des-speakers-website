---
key: tout_ce_que_vous_entendez_est_vrai
title: "Tout ce que vous entendez est vrai"
speakers:
  - william_bartlett 
type: autour_du_feu
day: 0
time: 16h00
duration: 15 minutes
room: autour_du_feu
---

Si c'est l'orateur.trice qui le dit, c'est que ça doit être vrai, n'est-ce pas ? Doublement, s'il s'agit d'un TED talk.

Nous avons une fâcheuse tendance à croire beaucoup de ce que nous entendons ou lisons tant cela ne rentre pas trop en conflit avec nos croyances.

Je vous raconterai trois histoires où la croyance aveugle a eu des conséquences désastreuses. Deux histoires seront vraies et une sera pure fiction. A vous de trouver laquelle.
