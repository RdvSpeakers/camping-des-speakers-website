---
key: comment_bien_foirer_vos_certifications_kubernetes_CK
title: "Comment bien foirer vos certifications Kubernetes CK{A,S}"
speakers:
  - remi_verchere
type: quechua
day: 1
time: 14h30
duration: 20 minutes
room: petite_salle
---

En début d'année 2021, j'ai tenté la Certification Kubernetes Administrator (CKA), et j'ai échoué au premier essai.
Cette année, j'ai également tenté la Certification Kubernetes Security Specialist (CKS), et j'ai à nouveau échoué au premier essai !

Avec ces expériences acquises sur le "fail" de certifications, je vous propose quelques astuces pour que vous ayez toutes les chances d'échec de votre côté !