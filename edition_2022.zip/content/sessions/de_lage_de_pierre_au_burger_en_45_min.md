---
key: de_lage_de_pierre_au_burger_en_45_min
title: "De l'âge de pierre 🗿au burger 🍔 en 45 min"
speakers:
  - gregory_bevan
  - guillaume_membre
type: bivouac
day: 1
time: 11h15
duration: 45 minutes
room: slideless
---

Pourquoi les barbecues sont-ils aussi fédérateur même en entreprise ? De l’allumage à la dégustation, nous vous expliquerons et surtout, montrerons comment préparer des bons burgers. Bien entendu, nous inviterons l’auteur de la célèbre loi de Murphy pour lui prouver que nous arriverons à nos fins !