---
key: sketchnote_en_vacances
title: "Sketchnote en Vacances"
speakers:
  - marc_dugue
  - sylvain_calmet
type: tente_cannadienne
day: 0
time: 10h15
duration: 45 minutes
room: grande_salle
---

Vous êtes au camping. Plus de batterie dans le téléphone, ou vous voulez vous reconnecter avec le réel, 
venez découvrir les sketchnotes sous l'angle du carnet de voyage. 
Armés d'un crayon, d'un stylo, d'un bout de charbon, 
faites un bout de chemin avec nous pour voir comment simplement poser sur le papier vos souvenirs de vacances.
Les sketchnotes peuvent être votre super pouvoir au travail et votre touche magique pour vos congés.

Sylvain et Marc seront vos guides dans ce petit bout de chemin pour un partage découverte sous la tente canadienne.