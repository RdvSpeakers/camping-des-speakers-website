---
key: jonglons_avec_les_microarchitectures
title: "Jonglons avec les microarchitectures front&nbsp;🤹"
speakers:
  - jean-francois_garreau 
type: autour_du_feu
day: 0
time: 13h30
duration: 15 minutes
room: autour_du_feu
---

D'un côté, le monde du web 🌐 qui évolue tout le temps et qui propose toujours plus de réutilisabilité grâce à des concepts comme les web components. Si on continue sur ce chemin, on va découvrir ce buzz. word du moment : "les micro-architectures front".

De l'autre le monde du jonglage 🎪 avec ses balles, ses massues qui à première vue sont différentes mais savent cohabiter curieusement bien pour qui sait les manier !

Quoi de mieux que le camping des speakers pour proposer un talk tentant de mélanger les concepts tout en donnant du sens à de la tech...? Dans ce talk, je me donne le défis de vous expliquer les concepts et enjeux qui se cachent derrière les micro-architectures front grâce au jonglage.
