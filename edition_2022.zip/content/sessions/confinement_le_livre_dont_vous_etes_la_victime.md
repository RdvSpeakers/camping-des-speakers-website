---
key: confinement_le_livre_dont_vous_etes_la_victime
title: "🏠 Confinement: le livre dont vous êtes la victime 😵"
speakers:
  - noel_mace
  - valeriane_venance
type: autour_du_feu
day: 0
time: 17h40
duration: 15 minutes
room: autour_du_feu
---

14 mars 2020, une nouvelle aventure commence et vous n'aviez rien demandé. Un voile sombre s'abat sur la communauté. Speakers et speakeuses sont isolés. Les devs sont confinés. Plus personne à qui parler. Comment l'ont-il surmonté ? Quelles leçons en garder ? Aujourd'hui, on va tout vous raconter !

15 minutes de conte moderne duquel nous ressortions plus forts ensemble.