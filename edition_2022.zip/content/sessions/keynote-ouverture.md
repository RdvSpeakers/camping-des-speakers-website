---
key: keynote-ouverture
title: "Keynote d'Ouverture"
speakers:
  - horacio_gonzalez
  - pierre_tibulle
type: quechua
day: 0
time: 09h20
duration: 20 minutes
room: grande_salle
---
