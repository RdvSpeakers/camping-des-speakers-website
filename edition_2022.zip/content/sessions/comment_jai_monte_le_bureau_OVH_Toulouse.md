---
key: comment_jai_monte_le_bureau_OVH_Toulouse
title: "Comment j'ai monté le bureau OVH Toulouse après un tweet"
speakers:
  - sylvain_wallez
type: tente_canadienne
day: 0
time: 14h30
duration: 45 minutes
room: grande_salle
---

Début 2015 j'ai répondu à un tweet d'Octave Klaba "pour déconner". Ce qui a suivi était totalement imprévisible : 3 mois plus tard j'ai monté le bureau OVH de Toulouse avec 10 personnes.

Je vais vous raconter cette histoire comme je l'ai vécue, avec sa succession d'événements improbables, la découverte d'une entreprise hors normes, et comment, en écoutant le père d'Octave Klaba me conter l'histoire de leur famille, j'ai compris la culture et le dynamisme de cette entreprise.

Le tweet par lequel tout a commencé : [https://twitter.com/bluxte/status/568708583740858368](https://twitter.com/bluxte/status/568708583740858368)