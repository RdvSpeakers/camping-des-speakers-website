---
key: partage_et_transmission
title: "Partage et transmission : ratages et amélioration"
speakers:
  - cecile_freyd-foucault
  - jordane_grenat
type: bivouac
day: 0
time: 17h10
duration: 45 minutes
room: slideless
---

Quel que soit le métier, l’expertise est importante. Que l’on soit designer, développeur, ops, chacun de nous maîtrise son domaine pour le bien du projet.

Mais être expert ne veut pas dire qu’on sait transmettre son savoir, ce qui est essentiel et vertueux dans nos métiers. Pourtant, les formations sont plutôt pauvres sur cet aspect.

Pour mieux collaborer, partageons mieux ! C’est ce que nous allons essayer de vous transmettre sous le prisme des différents contextes possibles.

Mentoring, partage, formation, les possibilités sont aussi nombreuses que les faux-pas probables et les bénéfices potentiels. Voyons ensemble comment réussir au mieux sa transmission pour armer au mieux les autres à transmettre !