---
key: depuis_2_ans_je_suis_la_seule_a_lire_mes_mails_ou_presque
title: "Depuis 2 ans, je suis la seule à lire mes mails ! (ou presque)"
speakers:
  - morgane_troysi
type: quechua
day: 1
time: 09h40
duration: 20 minutes
room: petite_salle
---

Que ce soit via notre mail, notre navigateur ou notre moteur de recherche, nos activités en ligne et nos informations personnelles n'ont plus de secret pour une poignée de sociétés qui dominent les outils que nous utilisons quotidiennement.
Pourtant, qui parmi-nous utilise toujours les outils de ces sociétés dont nous connaissons les pratiques ?

Peut-être faites-vous partie de ce nombre grandissant de personnes qui cherchent à entamer une transition vers des outils plus respectueux de la vie privée.

Mais par où commencer quand on n'est pas expert en cybersécurité ? Quelles sont les alternatives existantes et laquelle choisir si on ne veut pas perdre en qualité ?

Je vous propose de commencer par votre messagerie mail et de vous guider à travers les solutions existantes en vous présentant les critères qui font d'une messagerie un outil sécurisé !
