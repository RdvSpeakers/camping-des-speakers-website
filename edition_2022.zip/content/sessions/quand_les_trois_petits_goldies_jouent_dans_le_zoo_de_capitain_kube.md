---
key: quand_les_trois_petits_goldies_jouent_dans_le_zoo_de_capitain_kube
title: "Quand 'Les trois petits goldies' jouent dans le zoo de Capitain kube (édition slasher)"
speakers:
  - jerome_masson
type: tente_canadienne
day: 1
time: 11h15
duration: 45 minutes
room: petite_salle
---

Au travers du conte, pour enfant (ou pas), je revisite les 3 petits cochon: nos 3 petits goldies devront affronter le loup LitmusChaos!!!

Et si votre déploiement Golang devenez votre pire cauchemar (digne d'un film d'horreur) ? Faisons le point sur les patterns et anti-patterns des déploiements d'applications dans Kubernetes on-premise ou cloud provider: bonnes pratiques vs réalité (exploitation / coût).

Nous utiliserons LitmusChaos pour tester (détruire) notre application afin de démontrer les avantages et inconvénients des replicas / affinités / anti-affinités / multi-région / multi-cloud ...