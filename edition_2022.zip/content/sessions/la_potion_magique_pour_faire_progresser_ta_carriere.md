---
key: la_potion_magique_pour_faire_progresser_ta_carriere
title: "La potion magique pour faire progresser ta carrière"
speakers:
  - david_pilato
type: autour_du_feu
day: 1
time: 10h15
duration: 15 minutes
room: autour_du_feu
---

La recette de la potion magique ne se transmet qu'aux seuls druides, normalement. Mais exceptionnellement, le conseil des druides de la forêt des Carnutes m'a autorisé à vous révéler quelques uns des ingrédients qui constituent ce breuvage.

Il est même possible que je vous indique l'ingrédient secret !