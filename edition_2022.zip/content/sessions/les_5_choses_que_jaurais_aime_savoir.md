---
key: les_5_choses_que_jaurais_aime_savoir
title: "Les 5 choses que j'aurais aimé savoir plus tôt dans ma carrière"
speakers:
  - yohan_lasorsa 
type: autour_du_feu
day: 0
time: 17h10
duration: 15 minutes
room: autour_du_feu
---

Travailler dans la tech, c'est souvent regarder vers l'avant pour savoir où avancer et ne pas se retrouver à la traine, dans ce secteur constamment en mouvement. Pourtant, c'est parfois utile de jeter aussi un oeil en arrière pour se souvenir de toutes les fois où on s'est planté, parce que c'est comme cela qu'on apprend, et surtout pour ne pas refaire tout le temps les même erreurs.

A travers ce talk au coin du feu, j'aimerais partager 5 choses qui m'auraient été bien utiles de connaitre plus tôt dans ma carrière, à travers 5 anecdotes personnelles, beaucoup d'échecs et un poil de réussite.
