---
key: le_voyage_du_heros
title: "Le voyage du héros de l'IT"
speakers:
  - olivier_beautier
type: bivouac
day: 0
time: 16h00
duration: 45 minutes
room: slideless
---

Saviez-vous que vous étiez un expert en histoires ?

Pour preuve, vous êtes capable de prédire la scène suivante dans un film ou une série, voir même de deviner de suite qui est l'assassin! C'est tout à fait normal, car depuis notre plus jeune âge, nous sommes bercé d'histoires, de contes, de légendes, nous en avons intégré inconsciemment les mécaniques.

Dans ce talk original et interactif, nous allons utiliser le concept du Voyage du héros pour raconter une histoire, inspirée directement de vos expériences, et vous montrer que vous avez tout ce qu'il faut pour raconter de belles histoires à votre tour.


