---
key: au_secours_jai_un_homonyme
title: "Au secours 😨! J'ai un homonyme !! 😱"
speakers:
  - david_aparicio
type: autour_du_feau
day: 1
time: 11h15
duration: 15 minutes
room: autour_du_feu
---

Imaginez-vous, seul & l'unique [PRENOM] sur Terre, un cursus scolaire sans encombre, avec une famille parfaite. Tout se passe bien, quand soudain, lors d'une étape administrative, vous vous rendez compte que vous avez un homonyme. Et oui, c'est possible, même nom, même prénom et même date de naissance.

Je vais vous raconter ce cauchemar qui alourdit toutes les procédures : par exemple, permis, CAF voir même mes tests antigéniques Covid-19. Rien que du vécu !