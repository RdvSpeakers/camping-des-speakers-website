---
key: morgane_troysi
name: Morgane Troysi
company: Sfeir
city: Nantes, France
photoURL: speakers/morgane_troysi.jpg
socials:
  - icon: github
    link: https://github.com/mtroysi
    name: mtroysi
---
