---
key: elaine_dias_batista
name: Elaine Dias Batista
city: Paris, France
company: SFEIR
photoURL: speakers/elaine_dias_batista.jpg
socials:
  - icon: twitter
    link: https://twitter.com/elainedbatista
    name: elainedbatista
  - icon: github
    link: https://github.com/elainedb
    name: elainedb
---

Elaine has been working with mobile apps development for the past 6 years. Since the launch of the Google Assistant, she has been following the developments around that area. She truly believes that interacting with technology using natural language will define the future of computing. Born and raised in Brazil, she's been living in France since 2004 and loves everything multicultural. She's a GDE for the Google Assistant.