---
key: tiffany_souterre
name: Tiffany Souterre
company: Microsoft
city: Paris, France
photoURL: speakers/tiffany_souterre.jpg
socials:
  - icon: twitter
    link: https://twitter.com/tiffanysouterre
    name: tiffanysouterre
  - icon: github
    link: https://github.com/amagash
    name: amagash
---

I love science and I love data! After finishing a PhD in genetic engineering, I continued my quest for discovering new patterns through data science and machine learning. I worked for 3 years as a Data/ML Engineer and I am currently DevRel at Microsoft. Someday, I wish to leverage artificial intelligence and genetics to improve people's lives.