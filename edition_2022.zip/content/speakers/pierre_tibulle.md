---
key: pierre_tibulle
name: Pierre Tibulle
company: IKO-BOX
photoURL: team/pierre_tibulle.jpg
socials:
  - icon: twitter
    link: 'https://www.twitter.com/ptibulle'
    name: Twitter
  - icon: linkedin
    link: 'https://www.linkedin.com/in/pierre-tibulle-68674812b'
    name: LinkedIn

---
Dev mobile (Android/iOS/Hybride), CTO Ikobox, je gribouille des sketchnotes colorées et je participe à l'organisation du meetup Android Nantes (GDG).

