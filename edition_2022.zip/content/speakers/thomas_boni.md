---
key: thomas_boni
name: Thomas Boni
photoURL: speakers/thomas_boni.jpg
socials:
  - icon: twitter
    link: https://twitter.com/thomas_boni
    name: thomas_boni
---

I'm working hard to build systems that do all the work for me ✌️🏖️. CTO @R2Devops.io
