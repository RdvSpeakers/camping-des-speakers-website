---
key: david_aparicio
name: David Aparicio
company: OVHCloud
city: Lyon, France
photoURL: speakers/david_aparicio.jpg
socials:
  - icon: twitter
    link: https://twitter.com/dadideo
    name: dadideo
  - icon: github
    link: https://github.com/davidaparicio
    name: davidaparicio
---

Passionate engineer in Computer Science, graduated INSA Lyon 2014, after two years spent at UNICAMP in Brazil, actively participates in the community, through Meetups and conferences. His motto: “No developer is supposed to ignore security”.

Ingénieur passionné en Informatique, diplômé INSA Lyon 2014, après deux années passées à UNICAMP au Brésil, participe activement à la communauté, à travers des Meetups et des conférences. Sa devise: « Nul développeur n'est censé ignorer la sécurité ».