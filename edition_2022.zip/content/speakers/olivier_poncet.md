---
key: olivier_poncet
name: Olivier Poncet
company: HAWKSWELL
city: Massy, France
photoURL: speakers/olivier_poncet.jpg
socials:
  - icon: twitter
    link: https://twitter.com/ponceto91
    name: ponceto91
  - icon: github
    link: https://github.com/ponceto
    name: ponceto
---

Geek, ex-nerd repenti, je code, je teste, je bricole, je soude et parfois fait sauter les plombs. CTO et Software Craftsman, je suis libriste dans l'âme et suis très impliqué dans le mouvement des logiciels libres.