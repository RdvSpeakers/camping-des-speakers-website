---
key: oussama_ben_wafi
name: Oussama Ben Wafi
city: Paris, France
company: SFEIR
photoURL: speakers/oussama_ben_wafi.jpg
socials:
  - icon: twitter
    link: https://www.twitter.com/oussamto
    name: oussamto
---