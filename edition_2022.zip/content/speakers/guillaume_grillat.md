---
key: guillaume_grillat
name: Guillaume Grillat
company: leboncoin
city: Paris, France
photoURL: speakers/guillaume_grillat.jpg
socials:
  - icon: twitter
    link: https://twitter.com/grillatg
    name: grillatg
---

Un ex-recruteur devenu Tech Ambassadeur. Après avoir bossé des années en RH (cabinet de recrutement, agences digitales, pure-player), j’ai eu envie de rejoindre les équipes Engineering pour développer du partage de compétences/connaissances avec d’autres communautés tech (pure-players, meetups, associations etc.). Et on a créé le premier poste de Tech Ambassadeur chez Deezer.

Ayant rejoint depuis leboncoin, on a organisé la conférence lbc² en 2021, la première conférence tech made by leboncoin, avec notamment des interventions de  Netflix, Zalando, Doctolib : [https://www.lbc2.fr/](https://www.lbc2.fr/)

Entre galères et apprentissages, je vous raconte cette drôle d’aventure, et ce qu’une conférence a apporté au boncoin…et ce que ça m’a donné envie de faire. Le peer-learning, on a tous à y gagner (mais je ne suis pas en campagne 😄)
