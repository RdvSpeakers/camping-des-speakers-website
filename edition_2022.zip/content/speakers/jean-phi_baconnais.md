---
key: jean-phi_baconnais
name: Jean-Phi Baconnais
company: Zenika
city: Nantes, France
photoURL: speakers/jean-phi_baconnais.jpg
socials:
  - icon: twitter
    link: https://twitter.com/JPhi_Baconnais
    name: JPhi_Baconnais
  - icon: github
    link: https://github.com/jeanphibaconnais
    name: jeanphibaconnais
---

**Développeur / Consultant chez Zenika Nantes **

Plongé dans le développement avec l'éco-système Java, curieux de nature, j'aime découvrir et expérimenter de nouvelles technos back end ou front end et les partager autour de moi.

GitLab Heroes depuis l'été 2020 🦊