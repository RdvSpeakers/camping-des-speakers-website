---
key: estelle_landry
name: Estelle Landry ☀️
company: Pix
city: Montpellier, France
photoURL: speakers/estelle_landry.jpg
socials:
  - icon: twitter
    link: https://twitter.com/estelandry
    name: estelandry
---

Passionée par mon métier de Product Owner, par l'UX (User eXpérience) et le GameStorming, j'aime participer à l'élaboration d'un produit en étant le lien entre les utilisateurs et les développeurs.

Speakeuse en conférence tech, membre des Duchess France, de SunnyTech et du MeetUp UX Flupa Montpellier, je continue à me perfectionner et à discuter de nouvelles méthodes ou technologies de l'IT.