---
key: sylvain_wallez
name: Sylvain Wallez
company: Elastic
city: Toulouse, France
photoURL: speakers/sylvain_wallez.jpg
socials:
  - icon: twitter
    link: https://twitter.com/bluxte
    name: bluxte
  - icon: github
    link: https://github.com/swallez
    name: swallez
---