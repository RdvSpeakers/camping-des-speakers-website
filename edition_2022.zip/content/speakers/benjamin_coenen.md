---
key: benjamin_coenen
name: Benjamin Coenen
company: Apollo
city: Paris, France
photoURL: speakers/benjamin_coenen.jpg
socials:
  - icon: twitter
    link: https://twitter.com/bnj25
    name: bnj25
  - icon: github
    link: https://github.com/bnjjj
    name: bnjjj
---

Un belge perdu à Paris. Je suis tombé amoureux du développement informatique en écrivant de l'assembleur sur des microcontrôleurs. J'adore me battre avec des problèmes de performance. Aujourd'hui je développe un compilateur expérimental en Rust chez Cosmian. Toujours en recherche de comprendre ce qu'il se passe sous le capot je passe une bonne partie de mon temps à écrire du Rust & du Go. "Opensource everything" est mon objectif. Speaker à mes heures perdues. J'adore partager et contribuer dans la communauté tech et open source. Contributeur de Rust Analyzer, le compilateur expérimental pour IDE (https://github.com/rust-analyzer/rust-analyzer). Ancien contributeur actif de https://github.io/ovh/cds.