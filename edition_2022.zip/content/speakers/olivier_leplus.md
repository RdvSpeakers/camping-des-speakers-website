---
key: olivier_leplus
name: Olivier Leplus
company: Microsoft
city: Paris, France
photoURL: speakers/olivier_leplus.jpg
socials:
  - icon: twitter
    link: https://twitter.com/olivierleplus
    name: olivierleplus
  - icon: github
    link: https://github.com/tagazok
    name: tagazok
---

Developer Relation Program Manager at Microsoft and Google Developer Expert in Web Technologies. I love to share knowledge (and love) among developers and people in general.