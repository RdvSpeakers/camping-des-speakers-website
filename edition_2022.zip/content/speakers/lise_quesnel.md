---
key: lise_quesnel
name: Lise Quesnel
company: Zenika
city: Nantes, France
photoURL: speakers/lise_quesnel.jpg
socials:
  - icon: twitter
    link: https://twitter.com/QuesnelLise
    name: QuesnelLise
  - icon: github
    link: https://github.com/lisequesnel
    name: lisequesnel
---

Lise est développeuse web et Lead dev. Elle sait être moteur tant sur le plan humain que technique. Les bonnes pratiques de développement sont pour elle le ciment de tout projet. Elle porte également une attention toute particulière à l’expérience utilisateur. Grande curieuse, elle aime découvrir sans cesse de nouvelles choses.