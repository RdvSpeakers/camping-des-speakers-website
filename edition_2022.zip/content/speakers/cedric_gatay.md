---
key: cedric_gatay
name: Cedric Gatay
company: Code-Troopers
city: Tours, France
photoURL: speakers/cedric_gatay.jpg
socials:
  - icon: twitter
    link: https://twitter.com/Cedric_Gatay
    name: Cedric_Gatay
  - icon: github
    link: https://github.com/CedricGatay
    name: CedricGatay
---

Co-fondateur de Code-Troopers : studio de développement basé à Tours.

Co-lead du GDG Tours.

Initiateur de l'OpenDeviceLab de Tours.

Team member Touraine.tech : conférence autour du monde du développement en Touraine.