---
key: yvonnick_frin
name: Yvonnick Frin
company: Pix
city: Nantes, France
photoURL: speakers/yvonnick_frin.jpg
socials:
  - icon: twitter
    link: https://twitter.com/YvonnickFrin
    name: YvonnickFrin
  - icon: github
    link: https://github.com/frinyvonnick
    name: frinyvonnick
---

Yvonnick développeur chez Pix. Curieux et passionné, il aime découvrir les dernières technologies du Web. Social, il co-organise NantesJS.