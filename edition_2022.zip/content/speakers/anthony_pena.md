---
key: anthony_pena
name: Anthony PENA
company: SFEIR
city: Nantes, France
photoURL: speakers/anthony_pena.jpg
socials:
  - icon: twitter
    link: https://twitter.com/_Anthony_Pena
    name: _Anthony_Pena
  - icon: github
    link: https://github.com/kuroidoruido
    name: kuroidoruido
---

Codeur et blogueur le jour et dévoreur de manga la nuit, vous me verrez souvent parler de Java, JavaScript, Typescript, Rust ou de test, parfois un peu (beaucoup) de jeux-vidéos ou de bricolage de console.