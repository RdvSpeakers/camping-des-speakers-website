---
key: david_pilato
name: David Pilato
company: elastic
city: Cergy - Le Haut, Cergy, France
photoURL: speakers/david_pilato.jpg
socials:
  - icon: twitter
    link: https://twitter.com/dadoonet
    name: dadoonet
  - icon: github
    link: https://github.com/dadoonet
    name: dadoonet
---

Depuis 2013, David Pilato est développeur et évangéliste chez elastic.co, après avoir passé les deux années précédentes à promouvoir le projet open-source Elasticsearch. Il en anime la communauté française et organise des BBLs au sein des entreprises.