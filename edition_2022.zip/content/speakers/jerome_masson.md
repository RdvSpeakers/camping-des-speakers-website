---
key: jerome_masson
name: Jérôme Masson
company: 
city: Aix-en-Provence, France
photoURL: speakers/jerome_masson.jpg
socials:
  - icon: twitter
    link: https://twitter.com/sphinxgaiaone
    name: sphinxgaiaone
  - icon: github
    link: https://github.com/Sphinxgaia
    name: Sphinxgaia
---

Je me définis comme un Kubernetes addict & evangelist. Le landscape CNCF est un terrain de jeux qui est le parfait endroit pour un passionné comme moi. Ma carrière de consultant & d'architecte m'a amené à côtoyer des environnements complexes tant sur le plan humain que sur le plan technique.