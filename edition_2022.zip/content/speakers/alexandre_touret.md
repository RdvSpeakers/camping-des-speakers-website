---
key: alexandre_touret
name: Alexandre Touret
company: WORLDLINE
city: Tours, France
photoURL: speakers/alexandre_touret.jpg
socials:
  - icon: twitter
    link: https://twitter.com/touret_alex
    name: touret_alex
---

Je suis architecte et développeur sénior chez Worldline. Mon activité consiste à coder (principalement en Java), coacher des développeurs et concevoir des architectures.

Blog: [https://blog.touret.info](https://blog.touret.info)