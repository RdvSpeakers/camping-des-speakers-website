---
key: thibault_goudouneix
name: Thibault Goudouneix
company: ASI
city: Nantes, France
photoURL: speakers/thibault_goudouneix.jpg
socials:
  - icon: twitter
    link: https://twitter.com/nilmanduil
    name: nilmanduil
  - icon: github
    link: https://github.com/Nilmanduil
    name: Nilmanduil
---