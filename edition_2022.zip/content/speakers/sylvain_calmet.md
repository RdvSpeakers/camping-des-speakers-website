---
key: sylvain_calmet
name: Sylvain Calmet
company: Rail Europe
city: Nantes, France
photoURL: speakers/sylvain_calmet.jpg
socials:
  - icon: twitter
    link: https://twitter.com/calmetsylvain
    name: calmetsylvain
---
