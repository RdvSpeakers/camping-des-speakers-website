---
key: cecile_freyd-foucault
name: Cécile Freyd-Foucault
city: Paris, France
photoURL: speakers/cecile_freyd-foucault.jpg
socials:
  - icon: twitter
    link: https://twitter.com/cecilefreydf
    name: cecilefreydf
---

Tombée dans la soupe du design étant petite, je suis designeuse. Je parle avec autant de passion de typographie que de flow utilisateurs, accessibilité et surtout de design system 😍 !