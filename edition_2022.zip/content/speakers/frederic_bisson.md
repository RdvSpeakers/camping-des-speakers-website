---
key: frederic_bisson
name: Frédéric BISSON
city: Rouen, France
photoURL: speakers/frederic_bisson.jpg
socials:
  - icon: twitter
    link: https://twitter.com/zigazou
    name: zigazou
  - icon: github
    link: https://github.com/zigazou
    name: zigazou
---

Développeur web le jour, je remonte le temps des technologies pour découvrir comment on en est arrivé là.