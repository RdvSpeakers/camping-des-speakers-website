---
key: valeriane_venance
name: Valériane Venance
company: Twilio
city: Paris, France
photoURL: speakers/valeriane_venance.jpg
socials:
  - icon: twitter
    link: https://twitter.com/valeriane_IT
    name: valeriane_IT
  - icon: github
    link: https://github.com/vvenance
    name: vvenance
---

Valériane Venance is a developer evangelist at Twilio. She learnt code in école 42 and used to be a freelancer in web development and as deputy CTO. She loves to share experience and skills at conferences or by writing articles and talking with fellow devs. She also is involved in helping women and non-binary in tech via different associations.