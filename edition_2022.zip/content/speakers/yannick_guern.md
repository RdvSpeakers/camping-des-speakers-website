---
key: yannick_guern
name: Yannick Guern
company: Clever Cloud
city: Brest, France
photoURL: speakers/yannick_guern.jpg
socials:
  - icon: twitter
    link: https://twitter.com/_Akanoa_
    name: _Akanoa_
  - icon: github
    link: https://github.com/akanoa
    name: akanoa
---

Je suis un développeur de 29 ans qui aiment autant apprendre que de partager ce que j'apprends. Je n'ai pas réellement de spécialité, je fais du réseau, de l'admin système, du dev et récemment un tout petit peu d'UI.

Je développe un peu en tout : Javascript, PHP, Rust, Java.

Avec le confinement je me suis mis à streamer sur twitch mes séances de programmation qui finissent souvent en aide au développeur en difficulté ^^