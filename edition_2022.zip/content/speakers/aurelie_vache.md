---
key: aurelie_vache
name: Aurélie Vache
company: OVHcloud
city: Toulouse, France
photoURL: team/aurelie_vache.jpg
socials:
  - icon: twitter
    link: https://twitter.com/aurelievache
    name: aurelievache
  - icon: github
    link: https://github.com/scraly
    name: scraly
---

