---
key: jean-francois_garreau
name: Jean-François Garreau
company: Sfeir / GDG Nantes
city: Nantes, France
photoURL: speakers/jean-francois_garreau.jpg
socials:
  - icon: twitter
    link: https://twitter.com/jefbinomed
    name: jefbinomed
  - icon: github
    link: https://github.com/jefbinomed
    name: jefbinomed
---

GDE Web Technology & Mozilla Tech Speaker, je travaille pour Sfeir en tant que CTO de l'agence de Nantes. Je suis un fan de la Web Platform et m'amuse dès que je peux avec les standards :)

En dehors du travail, je suis co-fondateur du GDG Nantes, organisateur du DevFest Nantes, co-créateur des Nantes Wit

Retrouvez l'ensemble de mes contributions sur https://github.com/jefBinomed