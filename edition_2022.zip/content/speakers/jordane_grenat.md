---
key: jordane_grenat
name: Jordane Grenat
company: Comet Meetings
city: Tours, France
photoURL: speakers/jordane_grenat.jpg
socials:
  - icon: twitter
    link: https://twitter.com/JoGrenat
    name: JoGrenat
  - icon: github
    link: https://github.com/jgrenat
    name: jgrenat
---

Jordane est développeur chez Comet Meetings et adore les découvertes et ce qui sort de l'ordinaire. Ce qui est souvent incompatible avec le pragmatisme technologique nécessaire sur les projets clients.

Il assouvit alors sa passion à coup de projets perso jamais finis et en écumant les conférences en compagnie des autres développeurs férus de nouveautés. En vrac : Elm, F#, nouveau-framework-à-la-mode-JS, ...

Il passe le reste de son temps libre à refuser les cookies sur les sites web qu'il consulte.