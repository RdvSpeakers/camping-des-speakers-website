---
key: benjamin_dauvissat
name: Benjamin Dauvissat
city: Saint-Laurent-de-Chamousset, France
photoURL: speakers/benjamin_dauvissat.jpg
socials:
  - icon: twitter
    link: https://twitter.com/bdauvissat
    name: bdauvissat
---

Développeur Java depuis 15 ans

Scrum master depuis 5 ans

Egalement intéressé par l'intégration continue et le monde Elastic.

Bref, un peu curieux.