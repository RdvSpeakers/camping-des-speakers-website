---
key: marc_dugue
name: Marc Dugue
company: Conserto
city: Nantes, France
photoURL: speakers/marc_dugue.jpg
socials:
  - icon: twitter
    link: https://twitter.com/Marc_DUGUE
    name: Marc_DUGUE
---
Facilitateur graphique et directeur de projet.